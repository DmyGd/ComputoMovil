package com.spectrumhuv.garageit.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import com.spectrumhuv.garageit.Adapter.CategoryAdapter;
import com.spectrumhuv.garageit.Adapter.PopularAdapter;
import com.spectrumhuv.garageit.Domain.CategoryDomain;
import com.spectrumhuv.garageit.Domain.SaleDomain;
import com.spectrumhuv.garageit.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;


import java.util.ArrayList;

import static android.content.ContentValues.TAG;

public class MainActivity extends AppCompatActivity {
    private RecyclerView.Adapter adapter, adapter2;
    private RecyclerView recyclerViewCategoryList, recyclerViewPopularList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        recyclerViewCategory();
        recyclerViewPopular();
        bottomNavigation();
    }
    private void bottomNavigation() {
        FloatingActionButton floatingActionButton = findViewById(R.id.cardbtn);
        LinearLayout homeBtn = findViewById(R.id.homebtn);

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, CartListActivity.class));
            }
        });

        homeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, MainActivity.class));
            }
        });
    }

    private void recyclerViewPopular() {

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        //recyclerViewPopularList = findViewById(R.id.recyclerView2);
        recyclerViewPopularList.setLayoutManager(linearLayoutManager);

        ArrayList<SaleDomain> salelist = new ArrayList<>();
        salelist.add(new SaleDomain("Caja de Herramientas", "cajah", "Caja de Herramientas mulituso con capacidad adeacuada para guardar cualquier tipo de herramienta", 5.02));
        salelist.add(new SaleDomain("Cuadro", "cuadro", "Cuadro viejo elegante que le da un toque personal a cualquier espacio", 7.45));
        salelist.add(new SaleDomain("Tren de Madera", "tre", " Tren de madera antiguo aleman de la 2da guerra mundial", 8.5));

        //adapter2 = new PopularAdapter(salelist);
        recyclerViewPopularList.setAdapter(adapter2);

    }

    private void recyclerViewCategory() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        recyclerViewCategoryList = findViewById(R.id.recyclerView);
        recyclerViewCategoryList.setLayoutManager(linearLayoutManager);

        ArrayList<CategoryDomain> categoryList = new ArrayList<>();
        categoryList.add(new CategoryDomain("Herramientas", "herramienta"));
        categoryList.add(new CategoryDomain("Arte", "arte"));
        categoryList.add(new CategoryDomain("Juguetes", "jugue"));
        categoryList.add(new CategoryDomain("Coleccionista", "cat_4"));
        categoryList.add(new CategoryDomain("Souvenirs Extranjeros", "cat_5"));

        adapter = new CategoryAdapter(categoryList);
        recyclerViewCategoryList.setAdapter(adapter);
    }
}

}
